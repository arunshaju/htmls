$(document).mouseup(function(e) {
  /*
  var container = $(".group-field-wrap");
  if (!container.is(e.target) && container.has(e.target).length === 0) 
  {
      
  }
  */
});

// The cursor gets into the menu area
$('#menu').mouseenter(function(){
    // bodyFreezeScroll();
});